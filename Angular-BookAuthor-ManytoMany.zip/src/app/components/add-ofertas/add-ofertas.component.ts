import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-ofertas',
  templateUrl: './add-ofertas.component.html',
  styleUrls: ['./add-ofertas.component.css']
})
export class AddOfertasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
