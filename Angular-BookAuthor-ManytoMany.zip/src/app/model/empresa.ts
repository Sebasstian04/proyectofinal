export interface Ofertas{
    id?:'';
    razonsocial?:'';
    nit?:'';
  
}