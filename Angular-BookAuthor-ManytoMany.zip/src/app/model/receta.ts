export class Receta {
    id : number
    nombre : string
    cantidad : number
    ingredientes : string
    descripcion : string
}
