export class Usuario {
    id : number
    nombre : string
    apellido : string
    municipio : string
    correo : string
    cedula : number
    login : string
    password : string
}