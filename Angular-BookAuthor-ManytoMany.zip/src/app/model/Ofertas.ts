export interface Ofertas{
    id?:'';
    cargo?:'';
    fecha?:'';
    lugar?:'';
    descripcion?:'';
    salario?:'';
}