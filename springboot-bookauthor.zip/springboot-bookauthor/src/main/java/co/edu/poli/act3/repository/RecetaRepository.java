package co.edu.poli.act3.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import co.edu.poli.act3.model.Receta;


public interface RecetaRepository extends JpaRepository<Receta, Integer> {

}
