import { Receta } from './receta';

describe('receta', () => {
  it('should create an instance', () => {
    expect(new Receta()).toBeTruthy();
  });
});